﻿namespace Oracle_with_winform
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            textBoxID = new TextBox();
            label1 = new Label();
            label2 = new Label();
            textBoxName = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(405, 36);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(547, 326);
            dataGridView1.TabIndex = 0;
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
            // 
            // button1
            // 
            button1.Location = new Point(608, 415);
            button1.Name = "button1";
            button1.Size = new Size(188, 62);
            button1.TabIndex = 1;
            button1.Text = "Data Reader";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button_Click_DataReader;
            // 
            // button2
            // 
            button2.Location = new Point(802, 415);
            button2.Name = "button2";
            button2.Size = new Size(152, 62);
            button2.TabIndex = 2;
            button2.Text = "Check Conneaction";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(35, 415);
            button3.Name = "button3";
            button3.Size = new Size(162, 62);
            button3.TabIndex = 3;
            button3.Text = "Insert";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button_Click_Insert;
            // 
            // textBoxID
            // 
            textBoxID.Location = new Point(155, 36);
            textBoxID.Name = "textBoxID";
            textBoxID.Size = new Size(214, 31);
            textBoxID.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold);
            label1.Location = new Point(35, 33);
            label1.Name = "label1";
            label1.Size = new Size(40, 32);
            label1.TabIndex = 5;
            label1.Text = "ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold);
            label2.Location = new Point(35, 91);
            label2.Name = "label2";
            label2.Size = new Size(88, 32);
            label2.TabIndex = 7;
            label2.Text = "NAME";
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(155, 94);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(214, 31);
            textBoxName.TabIndex = 6;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(983, 516);
            Controls.Add(label2);
            Controls.Add(textBoxName);
            Controls.Add(label1);
            Controls.Add(textBoxID);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(dataGridView1);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Button button1;
        private Button button2;
        private Button button3;
        private TextBox textBoxID;
        private Label label1;
        private Label label2;
        private TextBox textBoxName;
    }
}
