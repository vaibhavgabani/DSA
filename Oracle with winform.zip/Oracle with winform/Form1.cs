using System.Data;
using System.Reflection.PortableExecutable;
using Oracle.ManagedDataAccess.Client;

namespace Oracle_with_winform
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string connectionString = "User Id = ORACLE; Password = ORACLE; Data Source:localhost:1521/XE";

        private void button_Click_DataReader(object sender, EventArgs e)
        {
            OracleConnection connection = new OracleConnection(connectionString);
            try
            {
                connection.Open();
                OracleCommand command = new OracleCommand("SELECT * FROM EMPLOYEE", connection);
                OracleDataReader reader = command.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView1.DataSource = dt;
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection Failed : " + ex);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OracleConnection connection = new OracleConnection(connectionString);
            try
            {
                connection.Open();
                MessageBox.Show("connected...");
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR : " + ex);
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                textBoxID.Text = selectedRow.Cells["EID"].Value.ToString();
                textBoxName.Text = selectedRow.Cells["NAME"].Value.ToString();
            }
        }

        private void button_Click_Insert(object sender, EventArgs e)
        {

        }
    }
}