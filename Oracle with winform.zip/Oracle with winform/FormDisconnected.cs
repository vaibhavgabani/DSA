﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;

namespace Oracle_with_winform
{
    public partial class FormDisconnected : Form
    {
        public FormDisconnected()
        {
            InitializeComponent();
        }
        DataSet ds = new DataSet();
        OracleDataAdapter adapter;
        DataTable dt;

        string connectionString = "User Id = ORACLE;Password = ORACLE; Data Source=localhost:1521/XE";

        private void button1_Click(object sender, EventArgs e)
        {
            OracleConnection connection = new OracleConnection(connectionString);
            try
            {
                connection.Open();
                MessageBox.Show("Connected...");
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error is : " + ex);
            }
        }

        private void LoadData()
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                try
                {
                    adapter = new OracleDataAdapter("SELECT * FROM EMPLOYEE", connection);
                    ds.Clear();
                    adapter.Fill(ds, "EMPLOYEE");
                    dt = ds.Tables["EMPLOYEE"];
                    dataGridView1.DataSource = dt; // Show data in DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void button_ClickInsert(object sender, EventArgs e)
        {
            using (OracleConnection connection = new OracleConnection(connectionString))
            {
                try
                {
                    OracleDataAdapter adapter = new OracleDataAdapter("SELECT * FROM EMPLOYEE", connection);
                    DataSet ds = new DataSet();
                    adapter.Fill(ds, "EMPLOYEE");
                    DataTable dt = ds.Tables["EMPLOYEE"];
                    DataRow newRow = dt.NewRow();
                    newRow["EID"] = Convert.ToInt32(textBox1.Text);
                    newRow["NAME"] = textBox2.Text;
                    dt.Rows.Add(newRow);
                    OracleCommandBuilder builder = new OracleCommandBuilder(adapter);
                    adapter.Update(ds, "EMPLOYEE");
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("ERROR : " + ex);
                }
            }
        }

        private void FormDisconnected_Load(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
